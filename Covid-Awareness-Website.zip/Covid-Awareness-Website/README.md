# COVID-Awareness-Website
It is a Covid19 Awareness Website made with simple HTML, CSS, and bootstrap.
It gives detail information about precautions, symptoms and the causes of Coronavirus guiding you about the various myth busters 
and activities taking place related to corona.
In short, it is the go-to website for anyone who wants information related to corona and its updates.

Created By:

### Tejas Tapas -
Github Id: Tejas1510

### Rishabh Rathi - 
Website: [Rishabh Rathi](http://www.rishabhrathi.co/)\
Github Id: [rishabhrathi22](https://github.com/rishabhrathi22)\
LinkedIn: [rishabhrathi22](https://www.linkedin.com/in/rishabhrathi22/)
